# My Package

This is a simple example package.

## Usage

```python
from my_package import hello

print(hello("World"))  # Output: Hello, World!
